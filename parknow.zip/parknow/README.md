# ParkNow

Sistema móvil para la gestión inteligente de parqueaderos urbanos.

Proyecto de la asignatura **Desarrollo de Aplicaciones Móviles Híbridas** – Universidad Compensar.

**Integrantes:** Sara Catalina Acosta Moreno, Javier Felipe Patiño Chaves, Jhon Jairo Martínez Forero.

## Avance actual

- Pantalla de inicio de sesión con validación de correo y contraseña.
- Pantalla de inicio (home) con reserva activa, buscador y listado de parqueaderos cercanos con su disponibilidad.
- Rutas protegidas: sin sesión solo se puede ver el login.

Por ahora la autenticación y los parqueaderos usan datos de prueba (`src/context/auth-context.tsx` y `src/data/parqueaderos.ts`) mientras se construye la API.

### Usuarios de prueba

| Rol | Correo | Contraseña |
| --- | --- | --- |
| Conductor | conductor@parknow.co | 123456 |
| Administrador | admin@parknow.co | admin123 |

## Tecnologías

- Expo SDK 57 / React Native 0.86
- React 19
- Expo Router
- TypeScript

## Cómo ejecutar

```bash
npm install
npx expo start
```

Luego escanear el QR con Expo Go, o presionar `a` (Android), `i` (iOS) o `w` (web).

## Estructura

```
src/
  app/          pantallas (login, home) y layout de navegación
  components/   componentes reutilizables
  constants/    paleta de colores
  context/      manejo de la sesión
  data/         datos de prueba
  utils/        funciones auxiliares
```
