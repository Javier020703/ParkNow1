import { useMemo, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

import ParkingCard from '@/components/parking-card';
import { Colors } from '@/constants/colors';
import { useAuth } from '@/context/auth-context';
import { parqueaderos, reservaActiva, type Parqueadero } from '@/data/parqueaderos';
import { confirmar, mostrarAlerta } from '@/utils/alerta';

type Filtro = 'todos' | 'disponibles' | 'cercanos';

const filtros: { id: Filtro; texto: string }[] = [
  { id: 'todos', texto: 'Todos' },
  { id: 'disponibles', texto: 'Con cupo' },
  { id: 'cercanos', texto: 'Más cercanos' },
];

export default function HomeScreen() {
  const { usuario, cerrarSesion } = useAuth();
  const [busqueda, setBusqueda] = useState('');
  const [filtro, setFiltro] = useState<Filtro>('todos');

  const lista = useMemo(() => {
    const texto = busqueda.trim().toLowerCase();
    let resultado = parqueaderos.filter(
      (p) => p.nombre.toLowerCase().includes(texto) || p.direccion.toLowerCase().includes(texto),
    );

    if (filtro === 'disponibles') {
      resultado = resultado.filter((p) => p.cuposLibres > 0);
    } else if (filtro === 'cercanos') {
      resultado = [...resultado].sort((a, b) => a.distanciaKm - b.distanciaKm);
    }
    return resultado;
  }, [busqueda, filtro]);

  const totalCupos = parqueaderos.reduce((suma, p) => suma + p.cuposLibres, 0);
  const primerNombre = usuario?.nombre.split(' ')[0] ?? '';

  const confirmarSalida = () => {
    confirmar('Cerrar sesión', '¿Seguro que quieres salir?', 'Salir', cerrarSesion);
  };

  const abrirParqueadero = (p: Parqueadero) => {
    mostrarAlerta(p.nombre, 'La reserva de espacios estará disponible en la siguiente entrega.');
  };

  const encabezado = (
    <>
      <View style={styles.header}>
        <View style={{ flex: 1 }}>
          <Text style={styles.saludo}>Hola, {primerNombre} 👋</Text>
          <Text style={styles.pregunta}>¿Dónde vas a parquear hoy?</Text>
        </View>
        <Pressable onPress={confirmarSalida} style={styles.avatar}>
          <Text style={styles.avatarTexto}>{primerNombre.charAt(0)}</Text>
        </Pressable>
      </View>

      {usuario?.rol === 'admin' && (
        <View style={styles.rolAdmin}>
          <Ionicons name="shield-checkmark" size={14} color={Colors.warning} />
          <Text style={styles.rolAdminTexto}>Sesión de administrador</Text>
        </View>
      )}

      <View style={styles.buscador}>
        <Ionicons name="search" size={20} color={Colors.textMuted} />
        <TextInput
          style={styles.buscadorInput}
          placeholder="Buscar parqueadero o dirección"
          placeholderTextColor={Colors.textMuted}
          value={busqueda}
          onChangeText={setBusqueda}
        />
        {!!busqueda && (
          <Pressable onPress={() => setBusqueda('')} hitSlop={10}>
            <Ionicons name="close-circle" size={18} color={Colors.textMuted} />
          </Pressable>
        )}
      </View>

      <View style={styles.reserva}>
        <View style={styles.reservaTop}>
          <Text style={styles.reservaEtiqueta}>RESERVA ACTIVA</Text>
          <Ionicons name="qr-code" size={22} color={Colors.white} />
        </View>
        <Text style={styles.reservaNombre}>{reservaActiva.parqueadero}</Text>
        <View style={styles.reservaFila}>
          <View>
            <Text style={styles.reservaDato}>Espacio</Text>
            <Text style={styles.reservaValor}>{reservaActiva.espacio}</Text>
          </View>
          <View>
            <Text style={styles.reservaDato}>Placa</Text>
            <Text style={styles.reservaValor}>{reservaActiva.placa}</Text>
          </View>
          <View>
            <Text style={styles.reservaDato}>Horario</Text>
            <Text style={styles.reservaValor}>
              {reservaActiva.horaInicio} - {reservaActiva.horaFin}
            </Text>
          </View>
        </View>
      </View>

      <View style={styles.resumen}>
        <View style={styles.resumenItem}>
          <Text style={styles.resumenNumero}>{parqueaderos.length}</Text>
          <Text style={styles.resumenTexto}>Parqueaderos cerca</Text>
        </View>
        <View style={styles.resumenDivisor} />
        <View style={styles.resumenItem}>
          <Text style={styles.resumenNumero}>{totalCupos}</Text>
          <Text style={styles.resumenTexto}>Cupos libres</Text>
        </View>
      </View>

      <Text style={styles.seccion}>Parqueaderos cercanos</Text>

      <View style={styles.filtros}>
        {filtros.map((f) => (
          <Pressable
            key={f.id}
            onPress={() => setFiltro(f.id)}
            style={[styles.chip, filtro === f.id && styles.chipActivo]}
          >
            <Text style={[styles.chipTexto, filtro === f.id && styles.chipTextoActivo]}>{f.texto}</Text>
          </Pressable>
        ))}
      </View>
    </>
  );

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <FlatList
        data={lista}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <ParkingCard parqueadero={item} onPress={() => abrirParqueadero(item)} />
        )}
        ListHeaderComponent={encabezado}
        ListEmptyComponent={
          <View style={styles.vacio}>
            <Ionicons name="car-outline" size={40} color={Colors.border} />
            <Text style={styles.vacioTexto}>No se encontraron parqueaderos</Text>
          </View>
        }
        contentContainerStyle={styles.contenido}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  contenido: {
    padding: 20,
    paddingBottom: 40,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  saludo: {
    fontSize: 24,
    fontWeight: '800',
    color: Colors.primary,
  },
  pregunta: {
    fontSize: 14,
    color: Colors.textMuted,
    marginTop: 2,
  },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.secondary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarTexto: {
    color: Colors.white,
    fontWeight: '700',
    fontSize: 18,
  },
  rolAdmin: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-start',
    backgroundColor: Colors.warning + '1A',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 20,
    marginBottom: 14,
  },
  rolAdminTexto: {
    color: Colors.warning,
    fontWeight: '600',
    fontSize: 12,
  },
  buscador: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: Colors.white,
    borderRadius: 14,
    paddingHorizontal: 14,
    borderWidth: 1,
    borderColor: Colors.border,
    marginBottom: 18,
  },
  buscadorInput: {
    flex: 1,
    paddingVertical: 13,
    fontSize: 15,
    color: Colors.text,
  },
  reserva: {
    backgroundColor: Colors.primary,
    borderRadius: 20,
    padding: 18,
    marginBottom: 16,
  },
  reservaTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  reservaEtiqueta: {
    color: Colors.light,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1,
  },
  reservaNombre: {
    color: Colors.white,
    fontSize: 18,
    fontWeight: '700',
    marginTop: 6,
    marginBottom: 14,
  },
  reservaFila: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  reservaDato: {
    color: Colors.light,
    fontSize: 11,
  },
  reservaValor: {
    color: Colors.white,
    fontSize: 14,
    fontWeight: '600',
    marginTop: 2,
  },
  resumen: {
    flexDirection: 'row',
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 16,
    marginBottom: 22,
  },
  resumenItem: {
    flex: 1,
    alignItems: 'center',
  },
  resumenDivisor: {
    width: 1,
    backgroundColor: Colors.border,
  },
  resumenNumero: {
    fontSize: 22,
    fontWeight: '800',
    color: Colors.secondary,
  },
  resumenTexto: {
    fontSize: 12,
    color: Colors.textMuted,
    marginTop: 2,
  },
  seccion: {
    fontSize: 18,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: 12,
  },
  filtros: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 14,
  },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: Colors.white,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  chipActivo: {
    backgroundColor: Colors.secondary,
    borderColor: Colors.secondary,
  },
  chipTexto: {
    fontSize: 13,
    color: Colors.textMuted,
    fontWeight: '600',
  },
  chipTextoActivo: {
    color: Colors.white,
  },
  vacio: {
    alignItems: 'center',
    paddingVertical: 40,
    gap: 8,
  },
  vacioTexto: {
    color: Colors.textMuted,
    fontSize: 14,
  },
});
