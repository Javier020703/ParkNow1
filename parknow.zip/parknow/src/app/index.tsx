import { Redirect } from 'expo-router';

import { useAuth } from '@/context/auth-context';

export default function Index() {
  const { usuario } = useAuth();
  return <Redirect href={usuario ? '/home' : '/login'} />;
}
