import { useState } from 'react';
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

import Input from '@/components/input';
import { Colors } from '@/constants/colors';
import { useAuth } from '@/context/auth-context';
import { mostrarAlerta } from '@/utils/alerta';

const regexCorreo = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function LoginScreen() {
  const { iniciarSesion } = useAuth();

  const [correo, setCorreo] = useState('');
  const [contrasena, setContrasena] = useState('');
  const [errores, setErrores] = useState<{ correo?: string; contrasena?: string }>({});
  const [errorGeneral, setErrorGeneral] = useState('');
  const [cargando, setCargando] = useState(false);

  const validar = () => {
    const nuevosErrores: typeof errores = {};

    if (!correo.trim()) {
      nuevosErrores.correo = 'Ingresa tu correo';
    } else if (!regexCorreo.test(correo.trim())) {
      nuevosErrores.correo = 'El correo no es válido';
    }

    if (!contrasena) {
      nuevosErrores.contrasena = 'Ingresa tu contraseña';
    } else if (contrasena.length < 6) {
      nuevosErrores.contrasena = 'Debe tener al menos 6 caracteres';
    }

    setErrores(nuevosErrores);
    return Object.keys(nuevosErrores).length === 0;
  };

  const handleLogin = async () => {
    setErrorGeneral('');
    if (!validar()) return;

    setCargando(true);
    try {
      await iniciarSesion(correo, contrasena);
      // la navegación al home la maneja Stack.Protected en el _layout
    } catch (e) {
      setErrorGeneral(e instanceof Error ? e.message : 'No se pudo iniciar sesión');
    } finally {
      setCargando(false);
    }
  };

  const proximamente = (funcion: string) => {
    mostrarAlerta('Próximamente', `${funcion} estará disponible en la siguiente entrega.`);
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
          <View style={styles.header}>
            <View style={styles.logo}>
              <Text style={styles.logoLetra}>P</Text>
            </View>
            <Text style={styles.titulo}>ParkNow</Text>
            <Text style={styles.subtitulo}>Encuentra, reserva y paga tu parqueadero</Text>
          </View>

          <View style={styles.formulario}>
            <Text style={styles.bienvenida}>Iniciar sesión</Text>

            {!!errorGeneral && (
              <View style={styles.alerta}>
                <Ionicons name="alert-circle" size={18} color={Colors.danger} />
                <Text style={styles.alertaTexto}>{errorGeneral}</Text>
              </View>
            )}

            <Input
              label="Correo electrónico"
              icon="mail-outline"
              placeholder="tucorreo@ejemplo.com"
              keyboardType="email-address"
              autoCapitalize="none"
              autoComplete="email"
              value={correo}
              onChangeText={(texto) => {
                setCorreo(texto);
                if (errores.correo) setErrores({ ...errores, correo: undefined });
              }}
              error={errores.correo}
            />

            <Input
              label="Contraseña"
              icon="lock-closed-outline"
              placeholder="••••••••"
              esContrasena
              autoCapitalize="none"
              value={contrasena}
              onChangeText={(texto) => {
                setContrasena(texto);
                if (errores.contrasena) setErrores({ ...errores, contrasena: undefined });
              }}
              error={errores.contrasena}
              onSubmitEditing={handleLogin}
            />

            <Pressable onPress={() => proximamente('La recuperación de contraseña')} style={styles.olvido}>
              <Text style={styles.link}>¿Olvidaste tu contraseña?</Text>
            </Pressable>

            <Pressable
              onPress={handleLogin}
              disabled={cargando}
              style={({ pressed }) => [styles.boton, (pressed || cargando) && { opacity: 0.85 }]}
            >
              {cargando ? (
                <ActivityIndicator color={Colors.white} />
              ) : (
                <Text style={styles.botonTexto}>Ingresar</Text>
              )}
            </Pressable>

            <View style={styles.separador}>
              <View style={styles.linea} />
              <Text style={styles.separadorTexto}>o continúa con</Text>
              <View style={styles.linea} />
            </View>

            <View style={styles.fila}>
              <Pressable style={styles.botonAlterno} onPress={() => proximamente('El inicio con Google')}>
                <Ionicons name="logo-google" size={20} color={Colors.primary} />
                <Text style={styles.botonAlternoTexto}>Google</Text>
              </Pressable>
              <Pressable style={styles.botonAlterno} onPress={() => proximamente('El acceso con huella')}>
                <Ionicons name="finger-print" size={20} color={Colors.primary} />
                <Text style={styles.botonAlternoTexto}>Huella</Text>
              </Pressable>
            </View>
          </View>

          <View style={styles.registro}>
            <Text style={styles.registroTexto}>¿No tienes cuenta? </Text>
            <Pressable onPress={() => proximamente('El registro')}>
              <Text style={[styles.link, { color: Colors.accent }]}>Regístrate</Text>
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: Colors.primary,
  },
  scroll: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 24,
  },
  header: {
    alignItems: 'center',
    marginBottom: 28,
  },
  logo: {
    width: 72,
    height: 72,
    borderRadius: 20,
    backgroundColor: Colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  logoLetra: {
    fontSize: 38,
    fontWeight: '900',
    color: Colors.white,
  },
  titulo: {
    fontSize: 30,
    fontWeight: '800',
    color: Colors.white,
  },
  subtitulo: {
    fontSize: 14,
    color: Colors.light,
    marginTop: 4,
  },
  formulario: {
    backgroundColor: Colors.white,
    borderRadius: 24,
    padding: 22,
  },
  bienvenida: {
    fontSize: 22,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: 18,
  },
  alerta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#FEE2E2',
    borderRadius: 10,
    padding: 10,
    marginBottom: 14,
  },
  alertaTexto: {
    color: Colors.danger,
    fontSize: 13,
    flex: 1,
  },
  olvido: {
    alignSelf: 'flex-end',
    marginBottom: 20,
    marginTop: -4,
  },
  link: {
    color: Colors.secondary,
    fontWeight: '600',
    fontSize: 14,
  },
  boton: {
    backgroundColor: Colors.secondary,
    borderRadius: 12,
    paddingVertical: 15,
    alignItems: 'center',
  },
  botonTexto: {
    color: Colors.white,
    fontSize: 16,
    fontWeight: '700',
  },
  separador: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 20,
    gap: 10,
  },
  linea: {
    flex: 1,
    height: 1,
    backgroundColor: Colors.border,
  },
  separadorTexto: {
    color: Colors.textMuted,
    fontSize: 13,
  },
  fila: {
    flexDirection: 'row',
    gap: 12,
  },
  botonAlterno: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    borderWidth: 1.5,
    borderColor: Colors.border,
    borderRadius: 12,
    paddingVertical: 12,
  },
  botonAlternoTexto: {
    color: Colors.primary,
    fontWeight: '600',
    fontSize: 14,
  },
  registro: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 22,
  },
  registroTexto: {
    color: Colors.white,
    fontSize: 14,
  },
});
