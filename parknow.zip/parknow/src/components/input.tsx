import { useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View, type TextInputProps } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Colors } from '@/constants/colors';

type Props = TextInputProps & {
  label: string;
  icon: keyof typeof Ionicons.glyphMap;
  error?: string;
  esContrasena?: boolean;
};

export default function Input({ label, icon, error, esContrasena, ...props }: Props) {
  const [oculto, setOculto] = useState(true);
  const [enfocado, setEnfocado] = useState(false);

  return (
    <View style={styles.contenedor}>
      <Text style={styles.label}>{label}</Text>
      <View
        style={[
          styles.campo,
          enfocado && styles.campoEnfocado,
          !!error && styles.campoError,
        ]}
      >
        <Ionicons name={icon} size={20} color={enfocado ? Colors.secondary : Colors.textMuted} />
        <TextInput
          style={styles.input}
          placeholderTextColor={Colors.textMuted}
          secureTextEntry={esContrasena && oculto}
          onFocus={() => setEnfocado(true)}
          onBlur={() => setEnfocado(false)}
          {...props}
        />
        {esContrasena && (
          <Pressable onPress={() => setOculto(!oculto)} hitSlop={10}>
            <Ionicons name={oculto ? 'eye-outline' : 'eye-off-outline'} size={20} color={Colors.textMuted} />
          </Pressable>
        )}
      </View>
      {!!error && <Text style={styles.error}>{error}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  contenedor: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 6,
  },
  campo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    borderWidth: 1.5,
    borderColor: Colors.border,
    borderRadius: 12,
    paddingHorizontal: 14,
    backgroundColor: Colors.white,
  },
  campoEnfocado: {
    borderColor: Colors.secondary,
  },
  campoError: {
    borderColor: Colors.danger,
  },
  input: {
    flex: 1,
    paddingVertical: 13,
    fontSize: 15,
    color: Colors.text,
  },
  error: {
    color: Colors.danger,
    fontSize: 12,
    marginTop: 4,
  },
});
