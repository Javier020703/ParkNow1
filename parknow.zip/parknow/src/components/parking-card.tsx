import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Colors } from '@/constants/colors';
import type { Parqueadero } from '@/data/parqueaderos';

type Props = {
  parqueadero: Parqueadero;
  onPress?: () => void;
};

function obtenerEstado(cupos: number, capacidad: number) {
  if (cupos === 0) return { texto: 'Lleno', color: Colors.danger };
  if (cupos / capacidad < 0.15) return { texto: 'Pocos cupos', color: Colors.warning };
  return { texto: 'Disponible', color: Colors.success };
}

export default function ParkingCard({ parqueadero, onPress }: Props) {
  const estado = obtenerEstado(parqueadero.cuposLibres, parqueadero.capacidad);
  const lleno = parqueadero.cuposLibres === 0;

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [styles.card, pressed && { opacity: 0.85 }]}
    >
      <View style={styles.icono}>
        <Ionicons name="car" size={24} color={Colors.secondary} />
      </View>

      <View style={styles.info}>
        <Text style={styles.nombre} numberOfLines={1}>{parqueadero.nombre}</Text>
        <Text style={styles.direccion} numberOfLines={1}>{parqueadero.direccion}</Text>

        <View style={styles.fila}>
          <View style={styles.dato}>
            <Ionicons name="navigate-outline" size={13} color={Colors.textMuted} />
            <Text style={styles.datoTexto}>{parqueadero.distanciaKm} km</Text>
          </View>
          <View style={styles.dato}>
            <Ionicons name="cash-outline" size={13} color={Colors.textMuted} />
            <Text style={styles.datoTexto}>${parqueadero.tarifaHora.toLocaleString('es-CO')}/h</Text>
          </View>
        </View>
      </View>

      <View style={styles.derecha}>
        <View style={[styles.badge, { backgroundColor: estado.color + '1A' }]}>
          <View style={[styles.punto, { backgroundColor: estado.color }]} />
          <Text style={[styles.badgeTexto, { color: estado.color }]}>{estado.texto}</Text>
        </View>
        <Text style={[styles.cupos, lleno && { color: Colors.textMuted }]}>
          {parqueadero.cuposLibres}
          <Text style={styles.capacidad}>/{parqueadero.capacidad}</Text>
        </Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 14,
    marginBottom: 12,
    gap: 12,
    shadowColor: Colors.primary,
    shadowOpacity: 0.06,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  icono: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: Colors.light + '55',
    alignItems: 'center',
    justifyContent: 'center',
  },
  info: {
    flex: 1,
  },
  nombre: {
    fontSize: 15,
    fontWeight: '700',
    color: Colors.text,
  },
  direccion: {
    fontSize: 12,
    color: Colors.textMuted,
    marginTop: 2,
  },
  fila: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 6,
  },
  dato: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
  },
  datoTexto: {
    fontSize: 12,
    color: Colors.textMuted,
  },
  derecha: {
    alignItems: 'flex-end',
    gap: 6,
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 20,
  },
  punto: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  badgeTexto: {
    fontSize: 11,
    fontWeight: '600',
  },
  cupos: {
    fontSize: 18,
    fontWeight: '800',
    color: Colors.primary,
  },
  capacidad: {
    fontSize: 12,
    fontWeight: '500',
    color: Colors.textMuted,
  },
});
