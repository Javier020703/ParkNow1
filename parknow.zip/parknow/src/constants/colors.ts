// Paleta definida en el documento del proyecto (sección 10)
export const Colors = {
  primary: '#02368A',
  secondary: '#0077B6',
  accent: '#00B4D8',
  light: '#90E0EF',
  white: '#FFFFFF',
  dark: '#03045E',
  warning: '#F97316',

  background: '#F4F8FC',
  text: '#0F1B33',
  textMuted: '#5B6B82',
  border: '#D9E3EF',
  success: '#16A34A',
  danger: '#DC2626',
};
