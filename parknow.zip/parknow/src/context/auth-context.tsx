import { createContext, useContext, useState, type ReactNode } from 'react';

export type Rol = 'usuario' | 'admin';

export type Usuario = {
  nombre: string;
  correo: string;
  rol: Rol;
};

type AuthContextType = {
  usuario: Usuario | null;
  iniciarSesion: (correo: string, contrasena: string) => Promise<void>;
  cerrarSesion: () => void;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// TODO: reemplazar por la API REST cuando esté lista
const usuariosPrueba = [
  { nombre: 'Sara Acosta', correo: 'conductor@parknow.co', contrasena: '123456', rol: 'usuario' as Rol },
  { nombre: 'Admin ParkNow', correo: 'admin@parknow.co', contrasena: 'admin123', rol: 'admin' as Rol },
];

export function AuthProvider({ children }: { children: ReactNode }) {
  const [usuario, setUsuario] = useState<Usuario | null>(null);

  const iniciarSesion = async (correo: string, contrasena: string) => {
    // simula la demora de la petición
    await new Promise((resolve) => setTimeout(resolve, 800));

    const encontrado = usuariosPrueba.find(
      (u) => u.correo === correo.trim().toLowerCase() && u.contrasena === contrasena,
    );

    if (!encontrado) {
      throw new Error('Correo o contraseña incorrectos');
    }

    setUsuario({ nombre: encontrado.nombre, correo: encontrado.correo, rol: encontrado.rol });
  };

  const cerrarSesion = () => setUsuario(null);

  return (
    <AuthContext.Provider value={{ usuario, iniciarSesion, cerrarSesion }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth debe usarse dentro de AuthProvider');
  }
  return context;
}
