// Datos de prueba mientras se conecta la API
export type Parqueadero = {
  id: string;
  nombre: string;
  direccion: string;
  distanciaKm: number;
  tarifaHora: number;
  cuposLibres: number;
  capacidad: number;
};

export const parqueaderos: Parqueadero[] = [
  {
    id: '1',
    nombre: 'Parqueadero Calle 72',
    direccion: 'Cra. 11 #72-35, Chapinero',
    distanciaKm: 0.4,
    tarifaHora: 6500,
    cuposLibres: 18,
    capacidad: 60,
  },
  {
    id: '2',
    nombre: 'Centro Comercial Andino',
    direccion: 'Cra. 11 #82-71, Chicó',
    distanciaKm: 1.2,
    tarifaHora: 8000,
    cuposLibres: 4,
    capacidad: 250,
  },
  {
    id: '3',
    nombre: 'ParkPlus Zona T',
    direccion: 'Cl. 83 #12-40, El Retiro',
    distanciaKm: 1.6,
    tarifaHora: 7200,
    cuposLibres: 0,
    capacidad: 45,
  },
  {
    id: '4',
    nombre: 'Parqueadero La Soledad',
    direccion: 'Cl. 41 #24-18, Teusaquillo',
    distanciaKm: 2.3,
    tarifaHora: 4800,
    cuposLibres: 27,
    capacidad: 40,
  },
  {
    id: '5',
    nombre: 'Estacionamiento Av. Chile',
    direccion: 'Cl. 72 #10-07, Chapinero',
    distanciaKm: 0.8,
    tarifaHora: 7000,
    cuposLibres: 9,
    capacidad: 80,
  },
];

export const reservaActiva = {
  parqueadero: 'Parqueadero Calle 72',
  espacio: 'B-14',
  placa: 'KLM 482',
  horaInicio: '2:30 p. m.',
  horaFin: '4:30 p. m.',
};
