import { Alert, Platform } from 'react-native';

// Alert.alert no hace nada en web, así que usamos las alertas del navegador
export function mostrarAlerta(titulo: string, mensaje: string) {
  if (Platform.OS === 'web') {
    window.alert(`${titulo}\n\n${mensaje}`);
  } else {
    Alert.alert(titulo, mensaje);
  }
}

export function confirmar(titulo: string, mensaje: string, textoAceptar: string, onAceptar: () => void) {
  if (Platform.OS === 'web') {
    if (window.confirm(`${titulo}\n\n${mensaje}`)) onAceptar();
    return;
  }

  Alert.alert(titulo, mensaje, [
    { text: 'Cancelar', style: 'cancel' },
    { text: textoAceptar, style: 'destructive', onPress: onAceptar },
  ]);
}
